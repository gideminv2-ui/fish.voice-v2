# -*- coding: utf-8 -*-
"""
Делает файл target_voice.txt — «отпечаток» целевого женского голоса (256 чисел) для fish.voice.

КАК ЗАПУСТИТЬ (проще всего, бесплатно, без установки чего-либо на компьютер):
  1. Откройте https://colab.research.google.com  ->  «Создать блокнот».
  2. Вставьте ВЕСЬ этот текст в первую ячейку и нажмите ▶.
  3. Когда появится кнопка «Выбрать файлы» — выберите WAV с женской речью.
  4. В конце скачается target_voice.txt (если нет — скопируйте строку чисел из вывода в файл руками).

Какой нужен образец: 5–15 секунд чистой речи одного человека, без музыки, шума и эха.
Формат любой (wav, mp3, m4a, ogg, aac, 3gp ...) — запись с телефона подойдёт.
Скрипт можно запускать и просто на компьютере/в GitHub Actions: python make_target_voice.py запись.m4a
Используйте только свой голос или голос человека, который разрешил это делать.

Первый запуск скачивает модель-«распознаватель диктора» (~400 МБ) — это занимает пару минут.
"""
import subprocess
import sys

subprocess.check_call([sys.executable, "-m", "pip", "install", "-q",
                       "onnxruntime", "huggingface_hub", "soundfile", "scipy", "numpy"])

from math import gcd

import numpy as np
import onnxruntime as ort
import soundfile as sf
from huggingface_hub import hf_hub_download, list_repo_files
from scipy.signal import resample_poly

REPO = "kiarina/MeanVC2-ONNX"
MAX_SECONDS = 15
SR = 16000

# --- 1. Берём WAV ---------------------------------------------------------
try:
    from google.colab import files  # type: ignore
    uploaded = files.upload()
    wav_path = next(iter(uploaded))
except ImportError:
    wav_path = sys.argv[1]

import shutil

wav = None
if shutil.which("ffmpeg"):
    # ffmpeg читает любые форматы и сразу приводит к 16 кГц, моно
    tmp_wav = "_voice_16k.wav"
    try:
        subprocess.check_call(["ffmpeg", "-y", "-loglevel", "error", "-i", wav_path,
                               "-ac", "1", "-ar", str(SR), "-t", str(MAX_SECONDS), tmp_wav])
        wav, sr = sf.read(tmp_wav, dtype="float32")
    except Exception as e:  # noqa: BLE001
        print("ffmpeg не справился, пробую напрямую:", e)
if wav is None:
    wav, sr = sf.read(wav_path, dtype="float32")
    if wav.ndim > 1:
        wav = wav.mean(axis=1)
    if sr != SR:
        g = gcd(sr, SR)
        wav = resample_poly(wav, SR // g, sr // g).astype(np.float32)
peak = float(np.abs(wav).max())
if peak > 1.0:
    wav = wav / peak
wav = wav[: SR * MAX_SECONDS]
if len(wav) < SR * 2:
    raise SystemExit("Образец слишком короткий: нужно хотя бы 2–3 секунды речи.")
print(f"Образец: {len(wav) / SR:.1f} с, 16 кГц, моно")

# --- 2. Скачиваем модель диктора (папка speaker/ в репозитории) -------------
spk_files = [f for f in list_repo_files(REPO) if f.startswith("speaker/")]
onnx_files = [f for f in spk_files if f.endswith(".onnx")]
if not onnx_files:
    raise SystemExit("В репозитории не найдена папка speaker/ с .onnx — структура изменилась.")
pick = next((f for f in onnx_files if "int8" in f), onnx_files[0])   # int8 меньше (~387 МБ)
print("Модель диктора:", pick)
local = None
for f in spk_files:
    if f == pick or f.startswith(pick):       # сам граф и возможные файлы внешних весов (.data)
        p = hf_hub_download(REPO, f)
        if f == pick:
            local = p

# --- 3. Считаем эмбеддинг ---------------------------------------------------
sess = ort.InferenceSession(local, providers=["CPUExecutionProvider"])
inp = sess.get_inputs()[0]
print("Вход модели:", inp.name, inp.shape, inp.type)
x = wav[None, :].astype(np.float32)           # [1, T]
if len(inp.shape) == 3:
    x = x[None]
emb = np.asarray(sess.run(None, {inp.name: x})[0], dtype=np.float32).reshape(-1)
if emb.size != 256:
    raise SystemExit(f"Ожидалось 256 чисел, модель вернула {emb.size}")
if not np.isfinite(emb).all():
    raise SystemExit("В результате есть NaN/inf — попробуйте другой образец.")

text = " ".join(f"{v:.8g}" for v in emb)
with open("target_voice.txt", "w") as fh:
    fh.write(text + "\n")
print("\nГотово: target_voice.txt (256 чисел).")
print(text[:120] + " ...")

try:
    files.download("target_voice.txt")         # только в Colab
except Exception:
    pass
