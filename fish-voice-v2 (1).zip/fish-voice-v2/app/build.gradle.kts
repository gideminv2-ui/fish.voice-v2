plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// ---------------------------------------------------------------------------
// ONNX Runtime: для C++ нужны заголовки и libonnxruntime.so из AAR-пакета.
// AAR скачивается обычной Gradle-зависимостью и распаковывается в build/ort,
// а CMake получает путь через -DORT_DIR и сам находит там заголовки и libonnxruntime.so.
// ---------------------------------------------------------------------------
val ortVersion = "1.26.0"

val ortAar: Configuration by configurations.creating {
    isCanBeConsumed = false
    isCanBeResolved = true
    isTransitive = false
}

val ortDir = layout.buildDirectory.dir("ort")

val extractOnnxRuntime = tasks.register<Copy>("extractOnnxRuntime") {
    from({ ortAar.resolve().map { zipTree(it) } })
    into(ortDir)
}

// Распаковка должна пройти до любой конфигурации/сборки CMake.
tasks.configureEach {
    if (name == "preBuild" ||
        name.startsWith("configureCMake") ||
        name.startsWith("buildCMake") ||
        name.startsWith("generateJsonModel") ||
        name.startsWith("externalNativeBuild")
    ) {
        dependsOn(extractOnnxRuntime)
    }
}

android {
    namespace = "fish.voice"
    compileSdk = 34
    ndkVersion = "26.3.11579264"

    defaultConfig {
        applicationId = "fish.voice"
        minSdk = 27            // NNAPI + AAudio (низкая задержка)
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"

        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }

        externalNativeBuild {
            cmake {
                cppFlags += listOf("-std=c++17")
                arguments += listOf(
                    "-DANDROID_STL=c++_shared",
                    "-DORT_DIR=${ortDir.get().asFile.absolutePath}"
                )
            }
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    buildFeatures {
        compose = true
        prefab = true          // Oboe подключается как prefab-пакет
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    androidResources {
        noCompress += "onnx"   // модель в assets не сжимаем
    }

    packaging {
        jniLibs {
            pickFirsts += setOf("**/libc++_shared.so")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")

    implementation("com.google.oboe:oboe:1.9.0")
    implementation("com.microsoft.onnxruntime:onnxruntime-android:$ortVersion")
    ortAar("com.microsoft.onnxruntime:onnxruntime-android:$ortVersion@aar")
}
