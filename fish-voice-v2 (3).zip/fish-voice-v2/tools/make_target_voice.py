# -*- coding: utf-8 -*-
"""
Делает файл target_voice.txt: «отпечаток» целевого женского голоса (256 чисел) для fish.voice.

Запуск:  python make_target_voice.py запись.mp3
(в Google Colab можно вставить в ячейку целиком: он сам попросит выбрать файл).

Образец: 5–15 секунд чистой речи одного человека, без музыки и шума. Формат любой.
Используйте только свой голос или голос человека, который разрешил.
"""
import os
import shutil
import subprocess
import sys
import time

# Скачивание: обычный HTTPS вместо xet (бывает, что xet в CI зависает) и без прогресс-баров в логе.
os.environ.setdefault("HF_HUB_DISABLE_XET", "1")
os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")
try:
    sys.stdout.reconfigure(line_buffering=True)
except Exception:  # noqa: BLE001
    pass

REPO = "kiarina/MeanVC2-ONNX"
MAX_SECONDS = 10
SR = 16000
T0 = time.time()


def log(*args):
    print(f"[{time.time() - T0:6.1f} c]", *args, flush=True)


def ensure_packages():
    need = []
    for mod, pkg in (("numpy", "numpy"), ("onnxruntime", "onnxruntime"), ("huggingface_hub", "huggingface_hub")):
        try:
            __import__(mod)
        except ImportError:
            need.append(pkg)
    if need:
        log("Устанавливаю:", ", ".join(need))
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", *need])


def load_audio(path):
    """Любой формат -> float32, моно, 16 кГц, не длиннее MAX_SECONDS."""
    import numpy as np

    if shutil.which("ffmpeg"):
        cmd = ["ffmpeg", "-nostdin", "-y", "-loglevel", "error", "-i", path,
               "-vn", "-ac", "1", "-ar", str(SR), "-t", str(MAX_SECONDS), "-f", "f32le", "pipe:1"]
        res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
        if res.returncode != 0:
            raise SystemExit("ffmpeg не смог прочитать запись: " + res.stderr.decode("utf-8", "replace")[:500])
        wav = np.frombuffer(res.stdout, dtype="<f4").astype(np.float32)
    else:  # запасной путь без ffmpeg (только wav/flac/ogg)
        import soundfile as sf
        from math import gcd
        from scipy.signal import resample_poly
        wav, sr = sf.read(path, dtype="float32")
        if wav.ndim > 1:
            wav = wav.mean(axis=1)
        if sr != SR:
            g = gcd(sr, SR)
            wav = resample_poly(wav, SR // g, sr // g).astype(np.float32)
        wav = wav[: SR * MAX_SECONDS]
    peak = float(np.abs(wav).max()) if wav.size else 0.0
    if peak > 1.0:
        wav = wav / peak
    return wav


def main():
    ensure_packages()
    import numpy as np
    import onnxruntime as ort
    from huggingface_hub import hf_hub_download, list_repo_files

    # --- 1. Запись ---
    try:
        from google.colab import files  # type: ignore
        uploaded = files.upload()
        wav_path = next(iter(uploaded))
    except ImportError:
        wav_path = sys.argv[1]
    log("Читаю запись:", wav_path)
    wav = load_audio(wav_path)
    if len(wav) < SR * 2:
        raise SystemExit("Запись слишком короткая: нужно хотя бы 2–3 секунды речи.")
    log(f"Образец: {len(wav) / SR:.1f} с, 16 кГц, моно")

    # --- 2. Модель диктора (папка speaker/ в репозитории) ---
    log("Ищу модель диктора на Hugging Face…")
    spk_files = [f for f in list_repo_files(REPO) if f.startswith("speaker/")]
    onnx_files = [f for f in spk_files if f.endswith(".onnx")]
    if not onnx_files:
        raise SystemExit("В репозитории нет папки speaker/ с .onnx — структура изменилась.")
    pick = next((f for f in onnx_files if "int8" in f), onnx_files[0])    # int8 меньше (~387 МБ)
    log("Скачиваю:", pick, "(несколько минут, ~400 МБ)")
    local = None
    for f in spk_files:
        if f == pick or f.startswith(pick):       # сам граф и файлы внешних весов (.data)
            p = hf_hub_download(REPO, f)
            log("  получено:", f, f"{os.path.getsize(p) / 1e6:.0f} МБ")
            if f == pick:
                local = p

    # --- 3. Эмбеддинг ---
    log("Загружаю модель в onnxruntime…")
    so = ort.SessionOptions()
    so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_BASIC   # быстрее и меньше памяти
    so.intra_op_num_threads = os.cpu_count() or 2
    sess = ort.InferenceSession(local, so, providers=["CPUExecutionProvider"])
    inp = sess.get_inputs()[0]
    log("Вход модели:", inp.name, inp.shape, inp.type)
    x = wav[None, :].astype(np.float32)           # [1, T]
    if len(inp.shape) == 3:
        x = x[None]
    log("Считаю отпечаток голоса…")
    emb = np.asarray(sess.run(None, {inp.name: x})[0], dtype=np.float32).reshape(-1)
    if emb.size != 256:
        raise SystemExit(f"Ожидалось 256 чисел, модель вернула {emb.size}")
    if not np.isfinite(emb).all():
        raise SystemExit("В результате есть NaN/inf — попробуйте другой образец.")

    text = " ".join(f"{v:.8g}" for v in emb)
    with open("target_voice.txt", "w") as fh:
        fh.write(text + "\n")
    log("Готово: target_voice.txt (256 чисел).")
    log(text[:100] + " ...")
    try:
        files.download("target_voice.txt")        # только в Colab
    except Exception:  # noqa: BLE001
        pass


if __name__ == "__main__":
    main()
