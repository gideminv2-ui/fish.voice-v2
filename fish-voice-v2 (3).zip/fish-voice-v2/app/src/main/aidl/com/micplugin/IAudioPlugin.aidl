// Контракт подключаемого модуля MicUp (github.com/papergray/MicUp).
// Взят из описания исходников хоста (app/src/main/aidl/com/micplugin/IAudioPlugin.aidl
// в папе-проекте MicUp), а не скопирован напрямую из файла — сеть недоступна для прямой
// сверки. Пакет и имя интерфейса должны совпадать с хостом один в один: по ним Android
// строит идентификатор связи (транзакции Binder), иначе MicUp эту службу не найдёт.
package com.micplugin;

interface IAudioPlugin {
    // JSON с именем модуля и описанием параметров (id/имя/границы).
    String getPluginInfo();

    // Обрабатывает моно-буфер звука на месте (inout). Вызывается на каждый короткий
    // блок аудио-потока MicUp — нельзя надолго задерживать выполнение.
    boolean processBuffer(inout float[] buffer, int frames, int sampleRate);

    void setParameter(int id, float value);
    float getParameter(int id);

    // Жизненный цикл: когда MicUp запускает/останавливает аудио-граф.
    void onStart(int sampleRate, int framesPerBuffer);
    void onStop();
}
