package fish.voice.plugin

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log
import com.micplugin.IAudioPlugin

/**
 * Делает fish.voice подключаемым модулем для MicUp (github.com/papergray/MicUp):
 * MicUp сам ловит микрофон, прогоняет звук через этот сервис по интерфейсу
 * IAudioPlugin и раздаёт результат как виртуальный микрофон другим приложениям
 * (Discord, игры и т.д.). Экран fish.voice при этом не нужен — всё идёт в фоне.
 *
 * ВАЖНО: не включайте одновременно «Запустить звук» на главном экране fish.voice —
 * оба режима используют одну и ту же модель и один и тот же микрофон, и будут мешать
 * друг другу. Либо наушники через fish.voice, либо этот модуль через MicUp.
 *
 * Контракт AIDL получен из описания исходников MicUp, а не сверен напрямую с байтами
 * файла на GitHub (сеть во время сборки этого ответа была недоступна для такой сверки).
 * Если MicUp не находит модуль или сразу его отключает — почти наверняка это здесь
 * разошлось на какую-то деталь; то, что покажет logcat по тегу AudioPluginService или
 * MicUp, укажет, что именно поправить.
 */
class AudioPluginService : Service() {

    private external fun nativeStart(sampleRate: Int, framesPerBuffer: Int): Boolean
    private external fun nativeStop()
    private external fun nativeProcess(buffer: FloatArray, frames: Int, sampleRate: Int): Boolean
    private external fun nativeSetParam(id: Int, value: Float)
    private external fun nativeGetParam(id: Int): Float

    private val binder = object : IAudioPlugin.Stub() {

        override fun getPluginInfo(): String = PLUGIN_INFO_JSON

        override fun processBuffer(buffer: FloatArray, frames: Int, sampleRate: Int): Boolean {
            return try {
                nativeProcess(buffer, frames, sampleRate)
            } catch (t: Throwable) {
                Log.e(TAG, "processBuffer упал", t)
                false
            }
        }

        override fun setParameter(id: Int, value: Float) {
            try {
                nativeSetParam(id, value)
            } catch (t: Throwable) {
                Log.e(TAG, "setParameter упал", t)
            }
        }

        override fun getParameter(id: Int): Float = try {
            nativeGetParam(id)
        } catch (t: Throwable) {
            Log.e(TAG, "getParameter упал", t)
            0f
        }

        override fun onStart(sampleRate: Int, framesPerBuffer: Int) {
            Log.i(TAG, "onStart: $sampleRate Гц, блок $framesPerBuffer")
            try {
                nativeStart(sampleRate, framesPerBuffer)
            } catch (t: Throwable) {
                Log.e(TAG, "onStart упал", t)
            }
        }

        override fun onStop() {
            Log.i(TAG, "onStop")
            try {
                nativeStop()
            } catch (t: Throwable) {
                Log.e(TAG, "onStop упал", t)
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onUnbind(intent: Intent?): Boolean {
        try {
            nativeStop()
        } catch (t: Throwable) {
            Log.e(TAG, "nativeStop при onUnbind упал", t)
        }
        return false
    }

    companion object {
        private const val TAG = "AudioPluginService"

        // Те же номера параметров, что в MainActivity.PARAM_* и native-lib.cpp (ParamId):
        // 0=ИИ, 1=Тембр, 2=Робот, 3=Эхо, 4=Искажение.
        private const val PLUGIN_INFO_JSON = """{
  "name": "fish.voice",
  "version": 1,
  "params": [
    {"id": 0, "name": "AI Voice",   "min": 0.0, "max": 1.0, "default": 0.0, "step": 1.0},
    {"id": 1, "name": "Timbre",     "min": 0.0, "max": 1.0, "default": 0.0},
    {"id": 2, "name": "Robot",      "min": 0.0, "max": 1.0, "default": 0.0},
    {"id": 3, "name": "Echo",       "min": 0.0, "max": 1.0, "default": 0.0},
    {"id": 4, "name": "Distortion", "min": 0.0, "max": 1.0, "default": 0.0}
  ]
}"""

        init {
            // Та же библиотека, что грузит MainActivity; повторный вызов для уже
            // загруженной библиотеки на Android безопасен и ничего не делает.
            System.loadLibrary("fishvoice")
        }
    }
}
