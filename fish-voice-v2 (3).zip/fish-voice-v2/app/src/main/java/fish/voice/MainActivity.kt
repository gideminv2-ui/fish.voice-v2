package fish.voice

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.io.File
import java.io.FileNotFoundException
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {

    // ---- JNI (реализация в native-lib.cpp) ----
    external fun startAudio()
    external fun stopAudio()
    external fun setParam(paramId: Int, value: Float)

    external fun initAi(modelDir: String, highQuality: Boolean): Boolean   // загрузка 5 ONNX-графов MeanVC2
    external fun setTargetVoice(embedding: FloatArray): Boolean   // 256 чисел целевого голоса
    external fun isAiReady(): Boolean
    external fun isAudioRunning(): Boolean
    external fun aiLoadMs(): Int                                  // время обработки одного куска 160 мс
    external fun aiError(): String

    // ---- состояние UI ----
    private var audioRunning by mutableStateOf(false)
    private var aiOn by mutableStateOf(false)
    private var aiReady by mutableStateOf(false)
    private var aiBusy by mutableStateOf(false)
    private var aiMessage by mutableStateOf("")
    private var aiProgress by mutableFloatStateOf(-1f)            // <0 — неопределённый
    private var aiProblem by mutableStateOf(false)
    private var highQuality by mutableStateOf(false)             // fp32-модели + 3 шага
    private var loadMs by mutableIntStateOf(0)
    private var timbre by mutableFloatStateOf(0f)
    private var robot by mutableFloatStateOf(0f)
    private var echo by mutableFloatStateOf(0f)
    private var distortion by mutableFloatStateOf(0f)
    private var error by mutableStateOf<String?>(null)

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startEngine() else error = "Нужен доступ к микрофону"
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        highQuality = getSharedPreferences("fish", MODE_PRIVATE).getBoolean("hq", false)
        prepareAi()
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFFFF4D8D),
                    background = Color(0xFF121218),
                    surface = Color(0xFF121218)
                )
            ) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Screen()
                }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        // Микрофон в фоне не держим.
        if (audioRunning) {
            stopAudio()
            audioRunning = false
        }
    }

    // ---- подготовка ИИ: скачать модели -> загрузить -> применить голос ----
    private fun ui(block: () -> Unit) = runOnUiThread(block)

    private fun prepareAi() {
        if (aiBusy) return
        val hq = highQuality
        if (isAiReady() && loadedHq == hq) {
            aiReady = true
            aiMessage = "ИИ готов"
            return
        }
        aiBusy = true
        aiReady = false
        aiProblem = false
        aiProgress = -1f
        aiMessage = "Проверяю файлы моделей…"
        thread(name = "ai-prepare") {
            try {
                val dir = File(filesDir, "meanvc2").apply { mkdirs() }
                downloadMissing(dir, hq)

                ui { aiProgress = -1f; aiMessage = "Загружаю модели в память…" }
                if (!initAi(dir.absolutePath, hq)) {
                    throw IllegalStateException(aiError().ifBlank { "не удалось загрузить модели" })
                }

                ui { aiMessage = "Применяю целевой голос и прогреваю модель…" }
                val voice = readVoice()
                if (!setTargetVoice(voice)) {
                    throw IllegalStateException(aiError().ifBlank { "не удалось применить голос" })
                }
                loadedHq = hq
                ui {
                    aiReady = true
                    aiProblem = false
                    aiMessage = "ИИ готов"
                }
            } catch (t: Throwable) {
                ui {
                    aiReady = false
                    aiProblem = true
                    aiMessage = t.message ?: t.toString()
                }
            } finally {
                ui { aiBusy = false }
            }
        }
    }

    /** Читает assets/target_voice.txt: ровно 256 чисел (эмбеддинг целевого голоса). */
    private fun readVoice(): FloatArray {
        val text = try {
            assets.open(VOICE_ASSET).bufferedReader().use { it.readText() }
        } catch (e: FileNotFoundException) {
            throw IllegalStateException(
                "Нет файла $VOICE_ASSET в app/src/main/assets. " +
                    "Создайте его по инструкции в README (шаг «Целевой голос»)."
            )
        }
        val nums = text.split(Regex("[\\s,;\\[\\]]+")).filter { it.isNotBlank() }.map {
            it.toFloatOrNull() ?: throw IllegalStateException("В $VOICE_ASSET нашлось не число: «$it»")
        }
        if (nums.size != 256) {
            throw IllegalStateException("В $VOICE_ASSET должно быть ровно 256 чисел, найдено ${nums.size}")
        }
        return nums.toFloatArray()
    }

    /** Скачивает недостающие файлы моделей с Hugging Face (один раз: ~74 МБ, для высокого качества ещё ~166 МБ). */
    private fun downloadMissing(dir: File, hq: Boolean) {
        val files = BASE_FILES + if (hq) HQ_FILES else FAST_FILES
        val total = files.sumOf { it.second }
        var doneBefore = 0L
        for ((name, approxSize) in files) {
            val target = File(dir, name)
            if (target.exists() && target.length() > 0) {
                doneBefore += approxSize
                continue
            }
            val part = File(dir, "$name.part")
            var conn: HttpURLConnection? = null
            try {
                conn = (URL(MODEL_BASE_URL + name).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 20_000
                    readTimeout = 30_000
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", "fish.voice/2.0")
                }
                if (conn.responseCode != HttpURLConnection.HTTP_OK) {
                    throw IOException("Сервер ответил ${conn.responseCode} на $name")
                }
                val expected = conn.contentLengthLong
                var written = 0L
                var lastUi = 0L
                conn.inputStream.use { input ->
                    part.outputStream().use { output ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            output.write(buf, 0, n)
                            written += n
                            val now = System.currentTimeMillis()
                            if (now - lastUi > 150) {
                                lastUi = now
                                val p = (doneBefore + written).toFloat() / total
                                val mb = (doneBefore + written) / 1_000_000
                                ui {
                                    aiProgress = p.coerceIn(0f, 1f)
                                    aiMessage = "Скачиваю модели: $mb из ${total / 1_000_000} МБ ($name)"
                                }
                            }
                        }
                    }
                }
                if (expected > 0 && written != expected) {
                    throw IOException("Загрузка $name оборвалась ($written из $expected байт). Повторите.")
                }
                if (!part.renameTo(target)) throw IOException("Не удалось сохранить $name")
            } catch (e: IOException) {
                part.delete()
                throw IOException("Не удалось скачать модели: ${e.message}. Проверьте интернет и повторите.")
            } finally {
                conn?.disconnect()
            }
            doneBefore += approxSize
        }
    }

    // ---- управление звуком ----
    private fun pushAllParams() {
        setParam(PARAM_AI, if (aiOn) 1f else 0f)
        setParam(PARAM_TIMBRE, timbre)
        setParam(PARAM_ROBOT, robot)
        setParam(PARAM_ECHO, echo)
        setParam(PARAM_DIST, distortion)
    }

    private fun startEngine() {
        error = null
        pushAllParams()
        startAudio()
        audioRunning = isAudioRunning()
        if (!audioRunning) error = "Не удалось открыть аудио-потоки"
    }

    private fun toggleAudio() {
        if (audioRunning) {
            stopAudio()
            audioRunning = false
            return
        }
        val granted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) startEngine() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    // ---- UI ----
    @Composable
    private fun Screen() {
        LaunchedEffect(audioRunning, aiOn) {
            while (true) {
                loadMs = if (audioRunning && aiOn) aiLoadMs() else 0
                delay(1000)
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("fish.voice v2", fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(
                "Используйте наушники — иначе микрофон «зазвенит» от динамика.",
                fontSize = 13.sp,
                color = Color(0xFFAAAAAA)
            )

            Spacer(Modifier.height(6.dp))

            OutlinedButton(
                onClick = { toggleAudio() },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Text(if (audioRunning) "■  Остановить звук" else "▶  Запустить звук")
            }

            // Большая кнопка-переключатель ИИ
            Button(
                onClick = {
                    aiOn = !aiOn
                    setParam(PARAM_AI, if (aiOn) 1f else 0f)
                },
                modifier = Modifier.fillMaxWidth().height(110.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (aiOn) Color(0xFFE91E63) else Color(0xFF2A2A35),
                    contentColor = Color.White
                )
            ) {
                Text(
                    "ИИ-Голос Девушки\n" + if (aiOn) "ВКЛ" else "ВЫКЛ",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Состояние ИИ
            when {
                aiBusy -> {
                    if (aiProgress in 0f..1f) {
                        LinearProgressIndicator(progress = { aiProgress }, modifier = Modifier.fillMaxWidth())
                    } else {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    }
                    Text(aiMessage, fontSize = 12.sp, color = Color(0xFFFFB74D))
                }
                aiReady -> {
                    Text(
                        "MeanVC2 готов" + if (aiOn && audioRunning && loadMs > 0) {
                            " · нагрузка: $loadMs мс из 160 мс"
                        } else "",
                        fontSize = 12.sp,
                        color = if (loadMs > 130) Color(0xFFFF6B6B) else Color(0xFF7BE0A0)
                    )
                    if (aiOn && loadMs > 130) {
                        Text(
                            if (highQuality) "Телефон не успевает: будут заикания. Выключите «Высокое качество»."
                            else "Телефон не успевает за голосом: будут заикания. Закройте другие приложения.",
                            fontSize = 12.sp,
                            color = Color(0xFFFF6B6B)
                        )
                    }
                    if (aiOn && audioRunning) {
                        Text(
                            "Задержка ИИ-голоса около 0,4–0,5 с — это нормально для MeanVC2.",
                            fontSize = 12.sp,
                            color = Color(0xFFAAAAAA)
                        )
                    }
                }
                else -> {
                    Text(
                        (if (aiProblem) aiMessage else "ИИ не готов") + "\nПока работает ручной режим.",
                        fontSize = 12.sp,
                        color = Color(0xFFFFB74D)
                    )
                    OutlinedButton(onClick = { prepareAi() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Повторить загрузку ИИ")
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Высокое качество", fontSize = 15.sp)
                    Text(
                        "Точные модели и 3 шага вместо 2. Звук чище, но нагрузка выше; " +
                            "при первом включении скачается ещё ~166 МБ.",
                        fontSize = 12.sp,
                        color = Color(0xFFAAAAAA)
                    )
                }
                Switch(
                    checked = highQuality,
                    enabled = !aiBusy,
                    onCheckedChange = {
                        highQuality = it
                        getSharedPreferences("fish", MODE_PRIVATE).edit().putBoolean("hq", it).apply()
                        prepareAi()
                    }
                )
            }

            Spacer(Modifier.height(8.dp))

            ParamSlider("Тембр (питч ×1.0…×1.5, только без ИИ)", timbre) {
                timbre = it; setParam(PARAM_TIMBRE, it)
            }
            ParamSlider("Робот", robot) {
                robot = it; setParam(PARAM_ROBOT, it)
            }
            ParamSlider("Эхо (300 мс)", echo) {
                echo = it; setParam(PARAM_ECHO, it)
            }
            ParamSlider("Искажение", distortion) {
                distortion = it; setParam(PARAM_DIST, it)
            }

            error?.let {
                Text(it, color = Color(0xFFFF6B6B), fontSize = 14.sp)
            }
        }
    }

    @Composable
    private fun ParamSlider(label: String, value: Float, onChange: (Float) -> Unit) {
        Column {
            Text("$label: ${(value * 100).roundToInt()}%", fontSize = 15.sp)
            Slider(
                value = value,
                onValueChange = onChange,
                valueRange = 0f..1f,
                colors = SliderDefaults.colors(thumbColor = Color(0xFFFF4D8D), activeTrackColor = Color(0xFFFF4D8D))
            )
        }
    }

    companion object {
        // Должны совпадать с enum ParamId в native-lib.cpp
        const val PARAM_AI = 0
        const val PARAM_TIMBRE = 1
        const val PARAM_ROBOT = 2
        const val PARAM_ECHO = 3
        const val PARAM_DIST = 4

        private const val VOICE_ASSET = "target_voice.txt"

        // Модели MeanVC2 (int8 для asr/dit/vocos): https://huggingface.co/kiarina/MeanVC2-ONNX
        // Имена файлов должны совпадать с теми, что ожидает native-lib.cpp (OrtBackend::load).
        private const val MODEL_BASE_URL = "https://huggingface.co/kiarina/MeanVC2-ONNX/resolve/main/"
        private val BASE_FILES = listOf(
            "fbank.onnx" to 908_000L,
            "gtm.onnx" to 17_400_000L
        )
        private val FAST_FILES = listOf(          // обычный режим (int8)
            "asr.int8.onnx" to 28_700_000L,
            "dit.int8.onnx" to 13_800_000L,
            "vocos.int8.onnx" to 13_000_000L
        )
        private val HQ_FILES = listOf(            // высокое качество (fp32)
            "asr.onnx" to 75_800_000L,
            "dit.onnx" to 53_600_000L,
            "vocos.onnx" to 36_500_000L
        )

        // Какой режим сейчас загружен в нативный движок (переживает пересоздание Activity).
        @Volatile private var loadedHq: Boolean? = null

        init {
            System.loadLibrary("fishvoice")
        }
    }
}
