// =============================================================================
//  fish.voice v2 — native-lib.cpp
//
//  Oboe (низкая задержка, дуплекс) + MeanVC2 (ONNX Runtime) + ручные DSP-эффекты.
//
//  Структура файла:
//    1. DSP-блок: кольцевой буфер, питч-шифтер, робот, эхо, дисторшн (без Android).
//    2. VC-блок: порт потокового конвейера MeanVC2 (onnx_stream.py) на C++,
//       не зависит ни от Android, ни от ONNX Runtime — его можно тестировать на ПК.
//    3. OrtBackend: вызовы пяти ONNX-графов (fbank, asr, gtm, dit, vocos).
//    4. AiEngine: рабочий поток инференса + буферы.
//    5. FishEngine: Oboe, вход/выход, onAudioReady.
//    6. JNI-функции для MainActivity.kt.
// =============================================================================

#include <jni.h>
#include <android/log.h>

#include <oboe/Oboe.h>

#include <onnxruntime_cxx_api.h>
#if __has_include(<nnapi_provider_factory.h>)
#include <nnapi_provider_factory.h>
#else
// Запасное объявление, если заголовок не попал в AAR.
extern "C" {
ORT_API_STATUS(OrtSessionOptionsAppendExecutionProvider_Nnapi,
               _In_ OrtSessionOptions* options, uint32_t nnapi_flags);
}
#endif

#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <functional>
#include <memory>
#include <mutex>
#include <random>
#include <string>
#include <thread>
#include <vector>

#define LOG_TAG "fish.voice"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// ----------------------------------------------------------------------------
//  Настройки
// ----------------------------------------------------------------------------
namespace cfg {
constexpr int   kSampleRate        = 16000;  // MeanVC2 работает строго на 16 кГц
constexpr int   kFramesPerCallback = 128;    // 128 или 256 — минимальный буфер Oboe
constexpr int   kMaxFrames         = 8192;   // защитный максимум кадров в одном колбэке
constexpr float kMaxPitchRatio     = 1.5f;   // Тембр = 100% -> коэффициент 1.5 (ручной режим)
constexpr int   kDitStepsFast      = 2;      // обычный режим: шагов ODE на кусок (1..3)
constexpr int   kDitStepsHq        = 3;      // «Высокое качество»: больше шагов + модели fp32 (медленнее)
constexpr int   kOrtThreads        = 2;      // потоков ONNX Runtime
constexpr bool  kUseNnapi          = false;  // NNAPI не любит динамические кэши и int8-ядра: по умолчанию CPU
constexpr int   kPrimeSamples      = 3200;   // запас на выходе перед стартом воспроизведения (200 мс)
}  // namespace cfg

// ID параметров для setParam() — должны совпадать с MainActivity.kt
enum ParamId : int {
    PARAM_AI      = 0,   // 0 / 1
    PARAM_TIMBRE  = 1,   // 0..1
    PARAM_ROBOT   = 2,   // 0..1
    PARAM_ECHO    = 3,   // 0..1
    PARAM_DIST    = 4,   // 0..1
    PARAM_COUNT   = 5
};

// ===================== DSP-BEGIN =============================================
namespace dsp {

constexpr float kPi = 3.14159265358979323846f;

// ---- Кольцевой буфер float (один писатель / один читатель, без блокировок) --
class FloatRing {
public:
    explicit FloatRing(size_t minCapacity = 1u << 16) {
        cap_ = 1;
        while (cap_ < minCapacity) cap_ <<= 1;
        buf_.assign(cap_, 0.0f);
    }
    size_t available() const {
        return head_.load(std::memory_order_acquire) - tail_.load(std::memory_order_acquire);
    }
    // Вызывает только писатель.
    size_t write(const float* src, size_t n) {
        const size_t h = head_.load(std::memory_order_relaxed);
        const size_t t = tail_.load(std::memory_order_acquire);
        n = std::min(n, cap_ - (h - t));
        for (size_t i = 0; i < n; ++i) buf_[(h + i) & (cap_ - 1)] = src[i];
        head_.store(h + n, std::memory_order_release);
        return n;
    }
    // Вызывает только читатель.
    size_t read(float* dst, size_t n) {
        const size_t t = tail_.load(std::memory_order_relaxed);
        const size_t h = head_.load(std::memory_order_acquire);
        n = std::min(n, h - t);
        for (size_t i = 0; i < n; ++i) dst[i] = buf_[(t + i) & (cap_ - 1)];
        tail_.store(t + n, std::memory_order_release);
        return n;
    }
    // Вызывает только читатель: выбросить n самых старых сэмплов.
    size_t skip(size_t n) {
        const size_t t = tail_.load(std::memory_order_relaxed);
        const size_t h = head_.load(std::memory_order_acquire);
        n = std::min(n, h - t);
        tail_.store(t + n, std::memory_order_release);
        return n;
    }
    // Только когда оба потока остановлены.
    void reset() {
        head_.store(0);
        tail_.store(0);
    }

private:
    std::vector<float> buf_;
    size_t cap_ = 0;
    std::atomic<size_t> head_{0};
    std::atomic<size_t> tail_{0};
};

// ---- Мягкий лимитер на выходе (защита ушей) ---------------------------------
inline float softLimit(float x) {
    const float a = std::fabs(x);
    if (a <= 0.9f) return x;
    const float y = 0.9f + 0.1f * std::tanh((a - 0.9f) / 0.1f);
    return x < 0.0f ? -y : y;
}

// ---- Питч/формант-шифтер: две линии задержки с кросс-фейдом (Hann) ----------
// Читающие "головки" движутся по кольцевому буферу со скоростью (ratio-1),
// что эквивалентно ресэмплингу: сдвигает и высоту тона, и форманты.
class PitchShifter {
public:
    void prepare(int sampleRate) {
        win_ = std::max(64, static_cast<int>(0.030f * static_cast<float>(sampleRate)));  // 30 мс
        int size = 1;
        while (size < win_ * 2 + 8) size <<= 1;
        buf_.assign(static_cast<size_t>(size), 0.0f);
        mask_ = size - 1;
        clear();
    }
    void clear() {
        std::fill(buf_.begin(), buf_.end(), 0.0f);
        w_ = 0;
        phase_ = 0.0f;
    }
    float process(float x, float ratio) {
        buf_[static_cast<size_t>(w_)] = x;
        float ph2 = phase_ + 0.5f;
        if (ph2 >= 1.0f) ph2 -= 1.0f;
        const float y = fade(phase_) * tap(phase_ * static_cast<float>(win_)) +
                        fade(ph2)    * tap(ph2    * static_cast<float>(win_));
        phase_ -= (ratio - 1.0f) / static_cast<float>(win_);
        if (phase_ < 0.0f)       phase_ += 1.0f;
        else if (phase_ >= 1.0f) phase_ -= 1.0f;
        w_ = (w_ + 1) & mask_;
        return y;
    }

private:
    static float fade(float p) { return 0.5f - 0.5f * std::cos(2.0f * kPi * p); }
    float tap(float delay) const {
        const float pos = static_cast<float>(w_) - delay;
        const int i0 = static_cast<int>(std::floor(pos));
        const float f = pos - static_cast<float>(i0);
        const float a = buf_[static_cast<size_t>(i0 & mask_)];
        const float b = buf_[static_cast<size_t>((i0 + 1) & mask_)];
        return a + (b - a) * f;
    }
    std::vector<float> buf_;
    int mask_ = 0, w_ = 0, win_ = 480;
    float phase_ = 0.0f;
};

// ---- Робот: STFT, у каждого кадра фаза обнуляется (остаётся только амплитуда) -
// Кадры идут с фиксированным шагом H, поэтому на выходе получается серия
// импульсов с постоянной частотой sr/H -> металлический "роботский" тембр.
class Robotizer {
public:
    static constexpr int N = 512;   // размер FFT
    static constexpr int H = 128;   // шаг (при 16 кГц -> 125 Гц)

    Robotizer() {
        for (int i = 0; i < N; ++i)
            win_[i] = 0.5f - 0.5f * std::cos(2.0f * kPi * static_cast<float>(i) / N);
        for (int k = 0; k < N / 2; ++k) {
            cosT_[k] = std::cos(2.0f * kPi * static_cast<float>(k) / N);
            sinT_[k] = std::sin(2.0f * kPi * static_cast<float>(k) / N);
        }
        const int bits = 9;  // log2(512)
        for (int i = 0; i < N; ++i) {
            int r = 0;
            for (int b = 0; b < bits; ++b)
                if (i & (1 << b)) r |= 1 << (bits - 1 - b);
            rev_[i] = r;
        }
        reset();
    }

    void reset() {
        std::fill(std::begin(in_),  std::end(in_),  0.0f);
        std::fill(std::begin(ola_), std::end(ola_), 0.0f);
        inPos_ = outPos_ = hopCnt_ = 0;
    }

    // mix: 0..1 (доля "робота"); "сухой" сигнал задерживается на N сэмплов,
    // чтобы совпасть по времени с обработанным.
    float process(float x, float mix) {
        const float dry = in_[inPos_];
        in_[inPos_] = x;
        inPos_ = (inPos_ + 1) & (N - 1);

        const float wet = ola_[outPos_];
        ola_[outPos_] = 0.0f;
        outPos_ = (outPos_ + 1) & (N - 1);

        if (++hopCnt_ == H) {
            hopCnt_ = 0;
            processFrame();
        }
        return dry * (1.0f - mix) + wet * mix;
    }

private:
    void fft(float* re, float* im) const {  // прямой FFT, in-place
        for (int i = 0; i < N; ++i) {
            const int j = rev_[i];
            if (j > i) { std::swap(re[i], re[j]); std::swap(im[i], im[j]); }
        }
        for (int len = 2; len <= N; len <<= 1) {
            const int half = len >> 1;
            const int step = N / len;
            for (int i = 0; i < N; i += len) {
                for (int k = 0; k < half; ++k) {
                    const float wr = cosT_[k * step];
                    const float wi = -sinT_[k * step];
                    const int a = i + k, b = a + half;
                    const float tr = re[b] * wr - im[b] * wi;
                    const float ti = re[b] * wi + im[b] * wr;
                    re[b] = re[a] - tr; im[b] = im[a] - ti;
                    re[a] += tr;        im[a] += ti;
                }
            }
        }
    }

    void processFrame() {
        float re[N], im[N];
        for (int i = 0; i < N; ++i) {
            re[i] = in_[(inPos_ + i) & (N - 1)] * win_[i];  // inPos_ = самый старый сэмпл
            im[i] = 0.0f;
        }
        fft(re, im);
        for (int i = 0; i < N; ++i) {          // обнуляем фазу: оставляем только модуль
            re[i] = std::sqrt(re[i] * re[i] + im[i] * im[i]);
            im[i] = 0.0f;
        }
        fft(re, im);   // спектр вещественный и симметричный -> прямой FFT == N * обратный
        const float scale = kGain / static_cast<float>(N);
        for (int i = 0; i < N; ++i) {
            const float v = re[(i + N / 2) & (N - 1)] * scale * win_[i];  // импульс -> в центр кадра
            ola_[(outPos_ + i) & (N - 1)] += v;
        }
    }

    static constexpr float kGain = 0.8f;
    float win_[N], cosT_[N / 2], sinT_[N / 2];
    int   rev_[N];
    float in_[N], ola_[N];
    int   inPos_ = 0, outPos_ = 0, hopCnt_ = 0;
};

// ---- Эхо: линия задержки 300 мс с обратной связью ---------------------------
class EchoLine {
public:
    void prepare(int sampleRate) {
        buf_.assign(static_cast<size_t>(0.300f * static_cast<float>(sampleRate)), 0.0f);
        pos_ = 0;
    }
    void clear() {
        std::fill(buf_.begin(), buf_.end(), 0.0f);
        pos_ = 0;
    }
    float process(float x, float amount) {
        const float d = buf_[pos_];
        buf_[pos_] = x + d * (0.5f * amount);      // обратная связь
        if (++pos_ >= buf_.size()) pos_ = 0;
        return x + d * (0.7f * amount);            // уровень эха
    }

private:
    std::vector<float> buf_;
    size_t pos_ = 0;
};

// ---- Набор ручных эффектов --------------------------------------------------
class ManualFx {
public:
    void prepare(int sampleRate) {
        sr_ = sampleRate;
        pitch_.prepare(sr_);
        echo_.prepare(sr_);
        robot_.reset();
        pitchMix_ = 0.0f; ratio_ = 1.0f;
        robotOn_ = false; robotMix_ = 0.0f;
        echoOn_ = false;  echoAmt_ = 0.0f;
    }

    // Тембр: 0 -> полный байпас; 1 -> коэффициент kMaxPitchRatio.
    void processPitch(const float* in, float* out, int n, float timbre) {
        const bool wantOn = timbre > 0.0005f;
        if (!wantOn && pitchMix_ <= 0.0f) {
            if (in != out) std::memcpy(out, in, sizeof(float) * static_cast<size_t>(n));
            return;
        }
        const float target = 1.0f + (cfg::kMaxPitchRatio - 1.0f) * timbre;
        if (wantOn && pitchMix_ <= 0.0f) {      // включение с нуля
            pitch_.clear();
            ratio_ = target;
        }
        const float mixStep = 1.0f / (0.05f * static_cast<float>(sr_));  // кросс-фейд 50 мс
        for (int i = 0; i < n; ++i) {
            if (wantOn) ratio_ += (target - ratio_) * 0.004f;
            pitchMix_ += wantOn ? mixStep : -mixStep;
            pitchMix_ = std::min(1.0f, std::max(0.0f, pitchMix_));
            const float x = in[i];
            const float y = pitch_.process(x, ratio_);
            out[i] = x * (1.0f - pitchMix_) + y * pitchMix_;
        }
    }

    // Робот -> Искажение -> Эхо. Каждый эффект при 0% полностью отключён.
    void processEffects(float* io, int n, float robot, float dist, float echo) {
        // --- Робот ---
        if (robot > 0.0005f) {
            if (!robotOn_) { robot_.reset(); robotMix_ = 0.0f; robotOn_ = true; }
            for (int i = 0; i < n; ++i) {
                robotMix_ += (robot - robotMix_) * 0.005f;
                io[i] = robot_.process(io[i], robotMix_);
            }
        } else if (robotOn_) {
            robot_.reset();
            robotOn_ = false;
        }

        // --- Искажение: gain + tanh (мягкий клиппинг) ---
        if (dist > 0.0005f) {
            const float gain = 1.0f + 49.0f * dist;
            const float comp = 1.0f / std::sqrt(std::sqrt(gain));  // компенсация громкости
            for (int i = 0; i < n; ++i) io[i] = std::tanh(gain * io[i]) * comp;
        }

        // --- Эхо ---
        if (echo > 0.0005f) {
            echoOn_ = true;
            for (int i = 0; i < n; ++i) {
                echoAmt_ += (echo - echoAmt_) * 0.005f;
                io[i] = echo_.process(io[i], echoAmt_);
            }
        } else if (echoOn_) {
            echo_.clear();          // 0% -> буфер очищен, эффект выключен
            echoOn_ = false;
            echoAmt_ = 0.0f;
        }

        for (int i = 0; i < n; ++i) io[i] = softLimit(io[i]);
    }

private:
    int sr_ = 16000;
    PitchShifter pitch_;
    Robotizer    robot_;
    EchoLine     echo_;
    float pitchMix_ = 0.0f, ratio_ = 1.0f;
    bool  robotOn_ = false;  float robotMix_ = 0.0f;
    bool  echoOn_  = false;  float echoAmt_  = 0.0f;
};

}  // namespace dsp
// ===================== DSP-END ===============================================

// ===================== VC-BEGIN ==============================================
//  Потоковый конвейер MeanVC2 — построчный порт onnx_stream.py (kiarina/meanvc2_onnx),
//  который в свою очередь повторяет upstream runtime/run_rt.py.
//  Модели вызываются через интерфейс Backend, поэтому логика (кэши, окно ASR,
//  интерполяция BN, цикл ODE, кросс-фейд вокодера) проверяется на ПК без моделей.
namespace vc {

constexpr int kChunk         = 2560;   // 160 мс при 16 кГц — сколько сэмплов подаём за раз
constexpr int kFbankLen      = 400;
constexpr int kFbankHop      = 160;
constexpr int kFbankDim      = 80;
constexpr int kBnWindow      = 19;
constexpr int kBnStride      = 16;
constexpr int kBnDim         = 256;
constexpr int kBnPerWindow   = 4;
constexpr int kRequiredCache = 8;
constexpr int kAsrOffsetInit = 8;
constexpr int kAsrOffsetStep = 4;
constexpr int kAttCacheSize  = 6 * 4 * 8 * 128;   // [6,4,8,128]
constexpr int kCnnCacheSize  = 6 * 1 * 256 * 8;   // [6,1,256,8]
constexpr int kChunkSize     = 12;     // кадров DiT за шаг (120 мс)
constexpr int kBlockSize     = 4;      // look-ahead (40 мс)
constexpr int kCondFrames    = kChunkSize + kBlockSize;   // 16
constexpr int kMelBins       = 80;
constexpr int kVocoderOverlap = 2;
constexpr int kWavOverlap    = 160;
constexpr int kWavPad        = (kVocoderOverlap - 1) * 160 - kWavOverlap;   // 0
constexpr int kSpkDim        = 256;
constexpr int kKvCount       = 8;      // k_cache0, v_cache0 ... k_cache3, v_cache3
constexpr int kKvHeads       = 2;
constexpr int kKvDim         = 64;
constexpr int kMaxPartsPerCall = 4;
constexpr int64_t kOffsetWrap = 4000;

// Кэш внимания DiT: форма [1, 2, len, 64]
struct KvCache {
    std::vector<float> data;
    int len = 0;
};

struct DitCall {
    const float* cond;      // [16 * 256]
    const float* spk;       // [256]
    const float* kMem;      // [memRows * 256]
    const float* vMem;
    int memRows;
    int64_t offset;
    const float* x;         // [16 * 80]
    float t, r;
    const KvCache* kv;      // kKvCount штук
};

// Пять графов модели. Все методы возвращают false при ошибке.
class Backend {
public:
    virtual ~Backend() = default;
    // frames [n,400] -> out [n*80]
    virtual bool fbank(const float* frames, int n, std::vector<float>& out) = 0;
    // xs [1,19,80]; обновляет att/cnn; bnOut = 4*256 float
    virtual bool asr(const float* xs, int64_t offset, int64_t requiredCache,
                     std::vector<float>& att, std::vector<float>& cnn, float* bnOut) = 0;
    // spks [1,256] -> k_mem, v_mem
    virtual bool gtm(const float* spk, std::vector<float>& kMem, std::vector<float>& vMem) = 0;
    // u [16*80] + 8 новых кэшей
    virtual bool dit(const DitCall& c, std::vector<float>& u, KvCache* kvOut) = 0;
    // mel [1,80,T] (по строкам: канал-major) -> wav
    virtual bool vocos(const float* mel, int frames, std::vector<float>& wav) = 0;
};

// F.interpolate(mode='linear', align_corners=True) по оси строк матрицы [n, c]
inline void interpLinearAlignCorners(const std::vector<float>& x, int n, int c, int size,
                                     std::vector<float>& out) {
    out.assign(static_cast<size_t>(size) * static_cast<size_t>(c), 0.0f);
    if (n == 1) {
        for (int r = 0; r < size; ++r)
            for (int ch = 0; ch < c; ++ch) out[static_cast<size_t>(r * c + ch)] = x[static_cast<size_t>(ch)];
        return;
    }
    const float step = static_cast<float>(static_cast<double>(n - 1) / static_cast<double>(size - 1));
    for (int k = 0; k < size; ++k) {
        const float pos = static_cast<float>(k) * step;
        int lo = static_cast<int>(std::floor(pos));
        lo = std::min(lo, n - 2);
        const float w = pos - static_cast<float>(lo);
        for (int ch = 0; ch < c; ++ch) {
            const float a = x[static_cast<size_t>(lo * c + ch)];
            const float b = x[static_cast<size_t>((lo + 1) * c + ch)];
            out[static_cast<size_t>(k * c + ch)] = a * (1.0f - w) + b * w;
        }
    }
}

class Pipeline {
public:
    using NoiseFn = std::function<void(float* dst, int count)>;

    Pipeline(Backend* backend, int steps) : be_(backend), steps_(std::max(1, steps)) {
        for (int i = 0; i < kWavOverlap; ++i) {
            down_[static_cast<size_t>(i)] = static_cast<float>(1.0 + static_cast<double>(i) * (-1.0 / (kWavOverlap - 1)));
            up_[static_cast<size_t>(i)]   = static_cast<float>(static_cast<double>(i) * (1.0 / (kWavOverlap - 1)));
        }
        down_[kWavOverlap - 1] = 0.0f;
        up_[kWavOverlap - 1]   = 1.0f;
        reset();
    }

    void setNoise(NoiseFn fn) { noise_ = std::move(fn); }

    // Целевой голос: 256 чисел (эмбеддинг диктора). Один раз на смену голоса.
    bool setTarget(const float* spk) {
        std::memcpy(spk_, spk, sizeof(spk_));
        if (!be_->gtm(spk_, kMem_, vMem_)) return false;
        memRows_ = static_cast<int>(kMem_.size() / kBnDim);
        hasTarget_ = true;
        reset();
        return true;
    }
    bool hasTarget() const { return hasTarget_; }

    void reset() {
        samplesCache_.clear();
        frameCache_.clear();
        hasEncCache_ = false;
        asrOffset_ = kAsrOffsetInit;
        att_.assign(kAttCacheSize, 0.0f);
        cnn_.assign(kCnnCacheSize, 0.0f);
        resetKv();
        vcOffset_ = 0;
        hasNoiseCache_ = false;
        hasVocCache_ = false;
        hasLastWav_ = false;
        bn_.clear();
    }

    // Подать любое число сэмплов; готовые сэмплы дописываются в out.
    // Порции выхода: 0, 1 или 2 куска по 1920 сэмплов за вызов kChunk.
    bool process(const float* samples, size_t n, std::vector<float>& out) {
        if (!hasTarget_) return false;
        const Enc e = encodeChunk(samples, n);
        if (e == Enc::Error) return false;
        if (e == Enc::None) return true;

        bn_.insert(bn_.end(), bnNew_.begin(), bnNew_.end());
        for (int part = 0; part < kMaxPartsPerCall; ++part) {
            if (static_cast<int>(bn_.size() / kBnDim) < kCondFrames) break;
            if (!vcStep(bn_.data())) return false;
            bn_.erase(bn_.begin(), bn_.begin() + static_cast<long>(kChunkSize) * kBnDim);
            if (!decodeMel(out)) return false;
        }
        return true;
    }

private:
    enum class Enc { None, Ok, Error };

    void resetKv() {
        kv_.assign(kKvCount, KvCache{});
        kvNew_.assign(kKvCount, KvCache{});
    }

    // ---- ASR ----
    Enc encodeChunk(const float* s, size_t n) {
        padded_ = samplesCache_;
        padded_.insert(padded_.end(), s, s + n);
        if (padded_.size() < static_cast<size_t>(kFbankLen)) {
            samplesCache_ = padded_;
            return Enc::None;
        }
        const int nf = 1 + static_cast<int>((padded_.size() - kFbankLen) / kFbankHop);
        frames_.resize(static_cast<size_t>(nf) * kFbankLen);
        for (int k = 0; k < nf; ++k)
            for (int j = 0; j < kFbankLen; ++j)
                frames_[static_cast<size_t>(k * kFbankLen + j)] =
                    padded_[static_cast<size_t>(k * kFbankHop + j)] * 32768.0f;
        if (!be_->fbank(frames_.data(), nf, fbOut_)) return Enc::Error;
        samplesCache_.assign(padded_.begin() + static_cast<long>(kFbankHop) * nf, padded_.end());

        fb_ = frameCache_;
        fb_.insert(fb_.end(), fbOut_.begin(), fbOut_.end());
        const int rows = static_cast<int>(fb_.size() / kFbankDim);

        if (asrOffset_ >= kOffsetWrap) asrOffset_ = std::max<int64_t>(kRequiredCache, asrOffset_ - kOffsetWrap);

        bnRows_.clear();
        int i = 0;
        float bn4[kBnPerWindow * kBnDim];
        while (i + kBnWindow <= rows) {
            if (!be_->asr(fb_.data() + static_cast<size_t>(i) * kFbankDim, asrOffset_, kRequiredCache,
                          att_, cnn_, bn4))
                return Enc::Error;
            bnRows_.insert(bnRows_.end(), bn4, bn4 + kBnPerWindow * kBnDim);
            asrOffset_ += kAsrOffsetStep;
            i += kBnStride;
        }
        frameCache_.assign(fb_.begin() + static_cast<long>(i) * kFbankDim, fb_.end());
        if (bnRows_.empty()) return Enc::None;

        if (hasEncCache_) bnRows_.insert(bnRows_.begin(), encCache_.begin(), encCache_.end());
        const int bnCount = static_cast<int>(bnRows_.size() / kBnDim);
        encCache_.assign(bnRows_.end() - kBnDim, bnRows_.end());
        hasEncCache_ = true;
        if (bnCount < 2) return Enc::None;

        interpLinearAlignCorners(bnRows_, bnCount, kBnDim, kCondFrames + 1, interp_);
        bnNew_.assign(interp_.begin() + kBnDim, interp_.end());   // [1:]
        return Enc::Ok;
    }

    // ---- DiT ----
    bool vcStep(const float* cond) {
        const int n = steps_;
        const double dt = 1.0 / n;
        x_.resize(static_cast<size_t>(kCondFrames) * kMelBins);
        if (noise_) {
            noise_(x_.data(), kCondFrames * kMelBins);
        } else {
            for (auto& v : x_) v = normal_(rng_);
        }
        if (hasNoiseCache_) std::copy(noiseCache_.begin(), noiseCache_.end(), x_.begin());
        noiseCache_.assign(x_.end() - kBlockSize * kMelBins, x_.end());
        hasNoiseCache_ = true;

        if (vcOffset_ >= kOffsetWrap) {
            vcOffset_ = 0;
            resetKv();
        }
        DitCall c{};
        c.cond = cond;
        c.spk = spk_;
        c.kMem = kMem_.data();
        c.vMem = vMem_.data();
        c.memRows = memRows_;
        c.offset = vcOffset_;
        c.kv = kv_.data();
        for (int i = 0; i < n; ++i) {
            const double tVal = 1.0 - i * dt;
            const double rVal = std::max(0.0, tVal - dt);
            c.x = x_.data();
            c.t = static_cast<float>(tVal);
            c.r = static_cast<float>(rVal);
            if (!be_->dit(c, u_, kvNew_.data())) return false;
            if (u_.size() != x_.size()) return false;
            const float fdt = static_cast<float>(dt);
            for (size_t j = 0; j < x_.size(); ++j) x_[j] = x_[j] - fdt * u_[j];
            if (i == n - 1) {
                for (int j = 0; j < kKvCount; ++j) kv_[static_cast<size_t>(j)] = std::move(kvNew_[static_cast<size_t>(j)]);
                kvNew_.assign(kKvCount, KvCache{});
            }
        }
        vcOffset_ += kChunkSize;

        // mel = x[:, :12, :].transpose -> [80, 12]
        mel_.resize(static_cast<size_t>(kMelBins) * kChunkSize);
        for (int t = 0; t < kChunkSize; ++t)
            for (int ch = 0; ch < kMelBins; ++ch)
                mel_[static_cast<size_t>(ch * kChunkSize + t)] = x_[static_cast<size_t>(t * kMelBins + ch)];
        return true;
    }

    // ---- Вокодер ----
    bool decodeMel(std::vector<float>& out) {
        const int prevT = hasVocCache_ ? kVocoderOverlap : 0;
        const int T = prevT + kChunkSize;
        melIn_.resize(static_cast<size_t>(kMelBins) * T);
        for (int ch = 0; ch < kMelBins; ++ch) {
            float* dst = melIn_.data() + static_cast<size_t>(ch) * T;
            if (prevT) std::memcpy(dst, vocCache_.data() + static_cast<size_t>(ch) * kVocoderOverlap,
                                   sizeof(float) * kVocoderOverlap);
            std::memcpy(dst + prevT, mel_.data() + static_cast<size_t>(ch) * kChunkSize, sizeof(float) * kChunkSize);
        }
        vocCache_.resize(static_cast<size_t>(kMelBins) * kVocoderOverlap);
        for (int ch = 0; ch < kMelBins; ++ch)
            for (int k = 0; k < kVocoderOverlap; ++k)
                vocCache_[static_cast<size_t>(ch * kVocoderOverlap + k)] =
                    melIn_[static_cast<size_t>(ch * T + T - kVocoderOverlap + k)];
        hasVocCache_ = true;
        for (auto& v : melIn_) v = (v + 1.0f) / 2.0f;

        if (!be_->vocos(melIn_.data(), T, wav_)) return false;
        const long L = static_cast<long>(wav_.size());
        if (hasLastWav_) {
            const float* w = wav_.data() + kWavPad;
            const long Lw = L - kWavPad;
            if (Lw < 2L * kWavOverlap) return false;
            for (int i = 0; i < kWavOverlap; ++i)
                out.push_back(lastWav_[static_cast<size_t>(i)] * down_[static_cast<size_t>(i)] +
                              w[i] * up_[static_cast<size_t>(i)]);
            for (long i = kWavOverlap; i < Lw - kWavOverlap; ++i) out.push_back(w[i]);
            lastWav_.assign(w + (Lw - kWavOverlap), w + Lw);
        } else {
            if (L < 2L * kWavOverlap) return false;
            for (long i = 0; i < L - kWavOverlap; ++i) out.push_back(wav_[static_cast<size_t>(i)]);
            lastWav_.assign(wav_.end() - kWavOverlap, wav_.end());
        }
        hasLastWav_ = true;
        return true;
    }

    Backend* be_;
    int steps_;
    NoiseFn noise_;
    std::mt19937 rng_{12345};
    std::normal_distribution<float> normal_{0.0f, 1.0f};

    float spk_[kSpkDim] = {};
    std::vector<float> kMem_, vMem_;
    int memRows_ = 0;
    bool hasTarget_ = false;

    // состояние ASR
    std::vector<float> samplesCache_, frameCache_, encCache_;
    bool hasEncCache_ = false;
    int64_t asrOffset_ = kAsrOffsetInit;
    std::vector<float> att_, cnn_;
    // состояние DiT
    std::vector<KvCache> kv_, kvNew_;
    int64_t vcOffset_ = 0;
    std::vector<float> noiseCache_;
    bool hasNoiseCache_ = false;
    // состояние вокодера
    std::vector<float> vocCache_, lastWav_;
    bool hasVocCache_ = false, hasLastWav_ = false;
    std::array<float, kWavOverlap> down_{}, up_{};
    // буфер BN между вызовами
    std::vector<float> bn_;

    // рабочие буферы (чтобы не выделять память на каждом куске)
    std::vector<float> padded_, frames_, fbOut_, fb_, bnRows_, interp_, bnNew_, x_, u_, mel_, melIn_, wav_;
};

}  // namespace vc
// ===================== VC-END ================================================

// ============================================================================
//  OrtBackend: пять графов MeanVC2 на ONNX Runtime.
//  Имена входов — ровно как в onnx_stream.py; выходы берутся по порядку графа.
//  Файлы (скачиваются приложением в filesDir/meanvc2):
//    обычный режим:  fbank.onnx, asr.int8.onnx, gtm.onnx, dit.int8.onnx, vocos.int8.onnx
//    высокое качество (fp32): fbank.onnx, asr.onnx, gtm.onnx, dit.onnx, vocos.onnx
// ============================================================================
class OrtBackend : public vc::Backend {
public:
    bool load(const std::string& dir, bool fp32, std::string& err) {
        try {
            env_ = std::make_unique<Ort::Env>(ORT_LOGGING_LEVEL_WARNING, "fish.voice");
            mem_ = std::make_unique<Ort::MemoryInfo>(
                Ort::MemoryInfo::CreateCpu(OrtArenaAllocator, OrtMemTypeDefault));
            if (!open(fbank_, dir + "/fbank.onnx", err)) return false;
            const std::string q = fp32 ? "" : ".int8";
            if (!open(asr_,   dir + "/asr" + q + ".onnx", err)) return false;
            if (!open(gtm_,   dir + "/gtm.onnx", err)) return false;
            if (!open(dit_,   dir + "/dit" + q + ".onnx", err)) return false;
            if (!open(vocos_, dir + "/vocos" + q + ".onnx", err)) return false;
            if (asr_.outPtrs.size() < 3 || dit_.outPtrs.size() < 1 + vc::kKvCount ||
                gtm_.outPtrs.size() < 2) {
                err = "Неожиданное число выходов у графов модели";
                return false;
            }
            return true;
        } catch (const Ort::Exception& e) {
            err = std::string("ONNX Runtime: ") + e.what();
        } catch (const std::exception& e) {
            err = std::string("Ошибка загрузки: ") + e.what();
        }
        return false;
    }

    bool fbank(const float* frames, int n, std::vector<float>& out) override {
        try {
            std::vector<Ort::Value> ins;
            ins.push_back(tensorF(frames, static_cast<size_t>(n) * vc::kFbankLen, {n, vc::kFbankLen}));
            const char* names[] = {"frames"};
            auto o = run(fbank_, names, ins);
            return copyOut(o[0], static_cast<size_t>(n) * vc::kFbankDim, out);
        } catch (const Ort::Exception& e) { LOGE("fbank: %s", e.what()); }
        return false;
    }

    bool asr(const float* xs, int64_t offset, int64_t requiredCache,
             std::vector<float>& att, std::vector<float>& cnn, float* bnOut) override {
        try {
            int64_t off = offset, req = requiredCache;
            std::vector<Ort::Value> ins;
            ins.push_back(tensorF(xs, static_cast<size_t>(vc::kBnWindow) * vc::kFbankDim,
                                  {1, vc::kBnWindow, vc::kFbankDim}));
            ins.push_back(scalarI64(&off));
            ins.push_back(scalarI64(&req));
            ins.push_back(tensorF(att.data(), att.size(), {6, 4, 8, 128}));
            ins.push_back(tensorF(cnn.data(), cnn.size(), {6, 1, 256, 8}));
            const char* names[] = {"xs", "offset", "required_cache_size", "att_cache", "cnn_cache"};
            auto o = run(asr_, names, ins);
            std::vector<float> bn, a2, c2;
            if (!copyOut(o[0], static_cast<size_t>(vc::kBnPerWindow) * vc::kBnDim, bn)) return false;
            if (!copyOut(o[1], vc::kAttCacheSize, a2)) return false;
            if (!copyOut(o[2], vc::kCnnCacheSize, c2)) return false;
            std::memcpy(bnOut, bn.data(), bn.size() * sizeof(float));
            att.swap(a2);
            cnn.swap(c2);
            return true;
        } catch (const Ort::Exception& e) { LOGE("asr: %s", e.what()); }
        return false;
    }

    bool gtm(const float* spk, std::vector<float>& kMem, std::vector<float>& vMem) override {
        try {
            std::vector<Ort::Value> ins;
            ins.push_back(tensorF(spk, vc::kSpkDim, {1, vc::kSpkDim}));
            const char* names[] = {"spks"};
            auto o = run(gtm_, names, ins);
            return copyOut(o[0], 0, kMem) && copyOut(o[1], 0, vMem) &&
                   kMem.size() % vc::kBnDim == 0 && !kMem.empty();
        } catch (const Ort::Exception& e) { LOGE("gtm: %s", e.what()); }
        return false;
    }

    bool dit(const vc::DitCall& c, std::vector<float>& u, vc::KvCache* kvOut) override {
        try {
            int64_t off = c.offset;
            float t = c.t, r = c.r;
            const size_t mem = static_cast<size_t>(c.memRows) * vc::kBnDim;
            std::vector<Ort::Value> ins;
            ins.push_back(tensorF(c.cond, static_cast<size_t>(vc::kCondFrames) * vc::kBnDim,
                                  {1, vc::kCondFrames, vc::kBnDim}));
            ins.push_back(tensorF(c.spk, vc::kSpkDim, {1, vc::kSpkDim}));
            ins.push_back(tensorF(c.kMem, mem, {1, c.memRows, vc::kBnDim}));
            ins.push_back(tensorF(c.vMem, mem, {1, c.memRows, vc::kBnDim}));
            ins.push_back(scalarI64(&off));
            for (int j = 0; j < vc::kKvCount; ++j) {
                const vc::KvCache& k = c.kv[j];
                ins.push_back(tensorF(k.data.data(), k.data.size(),
                                      {1, vc::kKvHeads, k.len, vc::kKvDim}));
            }
            ins.push_back(tensorF(c.x, static_cast<size_t>(vc::kCondFrames) * vc::kMelBins,
                                  {1, vc::kCondFrames, vc::kMelBins}));
            ins.push_back(tensorF(&t, 1, {1}));
            ins.push_back(tensorF(&r, 1, {1}));
            static const char* names[] = {
                "cond", "spks", "k_mem", "v_mem", "offset",
                "k_cache0", "v_cache0", "k_cache1", "v_cache1",
                "k_cache2", "v_cache2", "k_cache3", "v_cache3",
                "x", "t", "r"};
            auto o = run(dit_, names, ins);
            if (!copyOut(o[0], static_cast<size_t>(vc::kCondFrames) * vc::kMelBins, u)) return false;
            for (int j = 0; j < vc::kKvCount; ++j) {
                Ort::Value& v = o[static_cast<size_t>(1 + j)];
                const auto shape = v.GetTensorTypeAndShapeInfo().GetShape();
                if (shape.size() != 4 || shape[1] != vc::kKvHeads || shape[3] != vc::kKvDim) {
                    LOGE("dit: неожиданная форма кэша %d", j);
                    return false;
                }
                kvOut[j].len = static_cast<int>(shape[2]);
                if (!copyOut(v, 0, kvOut[j].data)) return false;
            }
            return true;
        } catch (const Ort::Exception& e) { LOGE("dit: %s", e.what()); }
        return false;
    }

    bool vocos(const float* mel, int frames, std::vector<float>& wav) override {
        try {
            std::vector<Ort::Value> ins;
            ins.push_back(tensorF(mel, static_cast<size_t>(vc::kMelBins) * frames,
                                  {1, vc::kMelBins, frames}));
            const char* names[] = {"mel"};
            auto o = run(vocos_, names, ins);
            return copyOut(o[0], 0, wav);
        } catch (const Ort::Exception& e) { LOGE("vocos: %s", e.what()); }
        return false;
    }

private:
    struct Net {
        std::unique_ptr<Ort::Session> s;
        std::vector<std::string> outNames;
        std::vector<const char*> outPtrs;
    };

    bool open(Net& n, const std::string& path, std::string& err) {
        Ort::SessionOptions so;
        so.SetIntraOpNumThreads(cfg::kOrtThreads);
        so.SetInterOpNumThreads(1);
        so.SetExecutionMode(ExecutionMode::ORT_SEQUENTIAL);
        so.SetGraphOptimizationLevel(GraphOptimizationLevel::ORT_ENABLE_ALL);
        if (cfg::kUseNnapi) {
            OrtStatus* st = OrtSessionOptionsAppendExecutionProvider_Nnapi(so, 0);
            if (st) {
                LOGW("NNAPI недоступен (%s) — CPU", Ort::GetApi().GetErrorMessage(st));
                Ort::GetApi().ReleaseStatus(st);
            }
        }
        try {
            n.s = std::make_unique<Ort::Session>(*env_, path.c_str(), so);
        } catch (const Ort::Exception& e) {
            err = "Не удалось загрузить " + path + ": " + e.what();
            return false;
        }
        Ort::AllocatorWithDefaultOptions alloc;
        const size_t cnt = n.s->GetOutputCount();
        n.outNames.clear();
        for (size_t i = 0; i < cnt; ++i)
            n.outNames.emplace_back(n.s->GetOutputNameAllocated(i, alloc).get());
        n.outPtrs.clear();
        for (const auto& s : n.outNames) n.outPtrs.push_back(s.c_str());
        LOGI("Загружен %s (выходов: %zu)", path.c_str(), cnt);
        return true;
    }

    Ort::Value tensorF(const float* p, size_t count, std::initializer_list<int64_t> shape) {
        static float dummy[4] = {0.f, 0.f, 0.f, 0.f};   // для пустых кэшей [1,2,0,64]
        return Ort::Value::CreateTensor<float>(*mem_, const_cast<float*>(count ? p : dummy), count,
                                               shape.begin(), shape.size());
    }
    Ort::Value scalarI64(int64_t* v) {
        static const int64_t kNoDims[1] = {0};
        return Ort::Value::CreateTensor<int64_t>(*mem_, v, 1, kNoDims, 0);
    }
    std::vector<Ort::Value> run(Net& n, const char* const* inNames, std::vector<Ort::Value>& ins) {
        return n.s->Run(Ort::RunOptions{nullptr}, inNames, ins.data(), ins.size(),
                        n.outPtrs.data(), n.outPtrs.size());
    }
    static bool copyOut(Ort::Value& v, size_t expect, std::vector<float>& dst) {
        if (!v.IsTensor()) return false;
        auto info = v.GetTensorTypeAndShapeInfo();
        if (info.GetElementType() != ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT) {
            LOGE("Выход графа не float32");
            return false;
        }
        const size_t cnt = info.GetElementCount();
        if (expect && cnt != expect) {
            LOGE("Неожиданный размер выхода: %zu вместо %zu", cnt, expect);
            return false;
        }
        const float* p = v.GetTensorData<float>();
        dst.assign(p, p + cnt);
        return true;
    }

    std::unique_ptr<Ort::Env> env_;
    std::unique_ptr<Ort::MemoryInfo> mem_;
    Net fbank_, asr_, gtm_, dit_, vocos_;
};

// ============================================================================
//  AiEngine: рабочий поток MeanVC2.
//  Колбэк Oboe только кладёт сэмплы в inRing_ и забирает готовые из outRing_.
//  Тяжёлые вызовы моделей идут здесь, в отдельном потоке.
// ============================================================================
class AiEngine {
public:
    ~AiEngine() { stopWorker(); }

    bool ready() const { return loaded_.load() && voiceSet_.load(); }
    bool loaded() const { return loaded_.load(); }
    bool voiceSet() const { return voiceSet_.load(); }
    float loadMs() const { return loadMs_.load(); }
    std::string lastError() const {
        std::lock_guard<std::mutex> lk(errMtx_);
        return err_;
    }

    // Загрузка пяти графов из каталога dir.
    bool loadModels(const std::string& dir, bool highQuality) {
        stopWorker();
        loaded_.store(false);
        voiceSet_.store(false);
        pipeline_.reset();
        backend_.reset();
        auto be = std::make_unique<OrtBackend>();
        std::string err;
        if (!be->load(dir, highQuality, err)) {
            setError(err);
            LOGE("%s", err.c_str());
            return false;
        }
        backend_ = std::move(be);
        pipeline_ = std::make_unique<vc::Pipeline>(backend_.get(),
                                                   highQuality ? cfg::kDitStepsHq : cfg::kDitStepsFast);
        LOGI("Режим: %s", highQuality ? "высокое качество (fp32, 3 шага)" : "обычный (int8, 2 шага)");
        setError("");
        loaded_.store(true);
        return true;
    }

    // Целевой голос: 256 чисел. Запускает gtm и прогревает конвейер.
    bool setVoice(const float* spk, size_t n) {
        stopWorker();
        voiceSet_.store(false);
        if (!loaded_.load() || !pipeline_) {
            setError("Сначала должны загрузиться модели");
            return false;
        }
        if (n != static_cast<size_t>(vc::kSpkDim)) {
            setError("Эмбеддинг голоса должен содержать ровно 256 чисел");
            return false;
        }
        if (!pipeline_->setTarget(spk)) {
            setError("Не удалось применить целевой голос (graph gtm)");
            return false;
        }
        // Прогрев: первые запуски ONNX Runtime заметно медленнее.
        std::vector<float> zeros(vc::kChunk, 0.0f), tmp;
        const auto t0 = std::chrono::steady_clock::now();
        for (int i = 0; i < 4; ++i) {
            tmp.clear();
            if (!pipeline_->process(zeros.data(), zeros.size(), tmp)) {
                setError("Прогревочный запуск модели не удался");
                return false;
            }
        }
        const float ms = std::chrono::duration<float, std::milli>(std::chrono::steady_clock::now() - t0).count();
        LOGI("Прогрев MeanVC2: %.0f мс на 4 куска", ms);
        pipeline_->reset();
        setError("");
        voiceSet_.store(true);
        return true;
    }

    void startWorker() {
        if (!ready() || running_.load()) return;
        inRing_.reset();
        outRing_.reset();
        active_.store(false);
        running_.store(true);
        worker_ = std::thread([this] { workerLoop(); });
    }
    void stopWorker() {
        running_.store(false);
        if (worker_.joinable()) worker_.join();
    }

    // ---- вызывается из аудио-колбэка ----
    void setActive(bool a) { active_.store(a, std::memory_order_relaxed); }
    void pushInput(const float* src, size_t n) { inRing_.write(src, n); }
    size_t outAvailable() const { return outRing_.available(); }
    size_t pullOutput(float* dst, size_t n) { return outRing_.read(dst, n); }
    void flushOutput() {
        float tmp[256];
        while (outRing_.read(tmp, 256) > 0) {}
    }

private:
    void setError(const std::string& e) {
        std::lock_guard<std::mutex> lk(errMtx_);
        err_ = e;
    }

    void workerLoop() {
        const size_t chunk = static_cast<size_t>(vc::kChunk);
        std::vector<float> in(chunk), out;
        out.reserve(8192);
        bool wasActive = false;
        int failures = 0;

        while (running_.load()) {
            if (!active_.load(std::memory_order_relaxed)) {
                wasActive = false;
                inRing_.skip(inRing_.available());      // пока ИИ выключен — отбрасываем звук
                std::this_thread::sleep_for(std::chrono::milliseconds(5));
                continue;
            }
            if (!wasActive) {                            // только что включили
                wasActive = true;
                pipeline_->reset();
            }
            const size_t avail = inRing_.available();
            if (avail < chunk) {
                std::this_thread::sleep_for(std::chrono::milliseconds(2));
                continue;
            }
            if (avail > chunk * 4) inRing_.skip(avail - chunk * 2);   // не даём задержке расти

            inRing_.read(in.data(), chunk);
            out.clear();
            const auto t0 = std::chrono::steady_clock::now();
            const bool ok = pipeline_->process(in.data(), chunk, out);
            const float ms = std::chrono::duration<float, std::milli>(std::chrono::steady_clock::now() - t0).count();
            loadMs_.store(loadMs_.load() * 0.9f + ms * 0.1f);
            if (!out.empty()) outRing_.write(out.data(), out.size());
            if (!ok && ++failures <= 3) LOGE("Ошибка обработки куска MeanVC2");
        }
    }

    std::unique_ptr<OrtBackend>   backend_;
    std::unique_ptr<vc::Pipeline> pipeline_;

    dsp::FloatRing inRing_{1u << 16};
    dsp::FloatRing outRing_{1u << 16};

    mutable std::mutex errMtx_;
    std::string err_;

    std::atomic<bool>  loaded_{false};
    std::atomic<bool>  voiceSet_{false};
    std::atomic<bool>  running_{false};
    std::atomic<bool>  active_{false};
    std::atomic<float> loadMs_{0.0f};
    std::thread worker_;
};

// ============================================================================
//  Аудио-движок на Oboe
//  Выходной поток — с колбэком onAudioReady; входной поток читается из этого
//  колбэка без блокировки (timeout = 0) и складывается в кольцевой буфер.
// ============================================================================
class FishEngine : public oboe::AudioStreamDataCallback,
                   public oboe::AudioStreamErrorCallback,
                   public std::enable_shared_from_this<FishEngine> {
public:
    FishEngine() : scratch_(cfg::kMaxFrames), dry_(cfg::kMaxFrames), micRing_(1u << 15) {
        for (auto& p : params_) p.store(0.0f);
    }

    // ---- управление ----
    bool start() {
        std::lock_guard<std::mutex> lk(mtx_);
        wantRunning_.store(true);
        return startLocked();
    }
    void stop() {
        std::lock_guard<std::mutex> lk(mtx_);
        wantRunning_.store(false);
        closeStreamsLocked();
    }
    bool isRunning() const { return running_.load(); }

    void setParam(int id, float v) {
        if (id < 0 || id >= PARAM_COUNT) return;
        v = std::min(1.0f, std::max(0.0f, v));
        params_[id].store(v, std::memory_order_relaxed);
    }

    AiEngine& ai() { return ai_; }

    // ---- Oboe: аудио-колбэк (поток реального времени) ----
    oboe::DataCallbackResult onAudioReady(oboe::AudioStream* /*stream*/, void* audioData,
                                          int32_t numFrames) override {
        float* out = static_cast<float*>(audioData);
        const int n = numFrames;
        if (n <= 0) return oboe::DataCallbackResult::Continue;
        if (n > cfg::kMaxFrames) {
            std::fill(out, out + n, 0.0f);
            return oboe::DataCallbackResult::Continue;
        }

        // 1. Забираем всё, что накопилось на микрофоне (неблокирующее чтение).
        if (inStream_) {
            for (int guard = 0; guard < 8; ++guard) {
                auto r = inStream_->read(scratch_.data(), cfg::kMaxFrames, 0);
                if (!r || r.value() <= 0) break;
                micRing_.write(scratch_.data(), static_cast<size_t>(r.value()));
                if (r.value() < cfg::kMaxFrames) break;
            }
        }

        // 2. Ограничиваем накопленную задержку (на старте и при перегрузке).
        const size_t un = static_cast<size_t>(n);
        const size_t avail = micRing_.available();
        if (avail > un * 4) micRing_.skip(avail - un * 2);

        // 3. Ровно n сэмплов "сухого" голоса (если не хватает — тишина).
        const size_t got = micRing_.read(dry_.data(), un);
        if (got < un) std::fill(dry_.begin() + static_cast<long>(got), dry_.begin() + n, 0.0f);

        // 4. Обработка
        const bool useAi = params_[PARAM_AI].load(std::memory_order_relaxed) > 0.5f && ai_.ready();
        if (useAi) {
            if (!lastUseAi_) {                                    // только что включили ИИ
                ai_.flushOutput();
                aiPrimed_ = false;
            }
            ai_.setActive(true);
            ai_.pushInput(dry_.data(), un);                       // мик -> ИИ
            // MeanVC2 отдаёт речь пачками (0, 1 или 2 куска за раз), поэтому
            // сначала копим запас на выходе, и только потом начинаем играть.
            if (!aiPrimed_ && ai_.outAvailable() >= static_cast<size_t>(cfg::kPrimeSamples)) aiPrimed_ = true;
            if (aiPrimed_) {
                const size_t m = ai_.pullOutput(out, un);         // ИИ -> наушники
                if (m < un) {                                     // не успел: тишина и новый набор запаса
                    std::fill(out + m, out + n, 0.0f);
                    aiPrimed_ = false;
                }
            } else {
                std::fill(out, out + n, 0.0f);
            }
        } else {
            ai_.setActive(false);
            fx_.processPitch(dry_.data(), out, n,
                             params_[PARAM_TIMBRE].load(std::memory_order_relaxed));
        }
        lastUseAi_ = useAi;

        fx_.processEffects(out, n,
                           params_[PARAM_ROBOT].load(std::memory_order_relaxed),
                           params_[PARAM_DIST].load(std::memory_order_relaxed),
                           params_[PARAM_ECHO].load(std::memory_order_relaxed));

        return oboe::DataCallbackResult::Continue;
    }

    // Наушники выдернули / сменилось устройство — перезапускаем потоки.
    void onErrorAfterClose(oboe::AudioStream* /*stream*/, oboe::Result error) override {
        LOGW("Ошибка потока: %s", oboe::convertToText(error));
        if (!wantRunning_.load()) return;
        bool expected = false;
        if (!restarting_.compare_exchange_strong(expected, true)) return;
        std::thread([self = shared_from_this()] {
            std::this_thread::sleep_for(std::chrono::milliseconds(150));
            {
                std::lock_guard<std::mutex> lk(self->mtx_);
                if (self->wantRunning_.load()) self->startLocked();
            }
            self->restarting_.store(false);
        }).detach();
    }

private:
    bool startLocked() {
        closeStreamsLocked();

        // --- Входной поток (микрофон): 16 кГц, моно, float ---
        oboe::AudioStreamBuilder inB;
        inB.setDirection(oboe::Direction::Input)
            ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
            ->setSharingMode(oboe::SharingMode::Exclusive)
            ->setFormat(oboe::AudioFormat::Float)
            ->setChannelCount(oboe::ChannelCount::Mono)
            ->setSampleRate(cfg::kSampleRate)
            ->setSampleRateConversionQuality(oboe::SampleRateConversionQuality::Medium)
            ->setFormatConversionAllowed(true)
            ->setChannelConversionAllowed(true)
            ->setInputPreset(oboe::InputPreset::VoicePerformance)
            ->setErrorCallback(shared_from_this());
        oboe::Result r = inB.openStream(inStream_);
        if (r != oboe::Result::OK) {
            LOGE("Не открылся входной поток: %s", oboe::convertToText(r));
            closeStreamsLocked();
            return false;
        }

        // --- Выходной поток (наушники) с колбэком ---
        oboe::AudioStreamBuilder outB;
        outB.setDirection(oboe::Direction::Output)
            ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
            ->setSharingMode(oboe::SharingMode::Exclusive)
            ->setFormat(oboe::AudioFormat::Float)
            ->setChannelCount(oboe::ChannelCount::Mono)
            ->setSampleRate(cfg::kSampleRate)
            ->setSampleRateConversionQuality(oboe::SampleRateConversionQuality::Medium)
            ->setFormatConversionAllowed(true)
            ->setChannelConversionAllowed(true)
            ->setUsage(oboe::Usage::Media)
            ->setFramesPerDataCallback(cfg::kFramesPerCallback)
            ->setDataCallback(shared_from_this())
            ->setErrorCallback(shared_from_this());
        r = outB.openStream(outStream_);
        if (r != oboe::Result::OK) {
            LOGE("Не открылся выходной поток: %s", oboe::convertToText(r));
            closeStreamsLocked();
            return false;
        }

        // Минимальный буфер вывода: 2 "burst"
        outStream_->setBufferSizeInFrames(outStream_->getFramesPerBurst() * 2);

        const int sr = outStream_->getSampleRate();
        LOGI("Потоки открыты: вход %d Гц, выход %d Гц, burst %d, колбэк %d кадров",
             inStream_->getSampleRate(), sr, outStream_->getFramesPerBurst(),
             outStream_->getFramesPerDataCallback());

        fx_.prepare(sr);
        micRing_.reset();
        lastUseAi_ = false;
        aiPrimed_ = false;
        ai_.startWorker();

        r = inStream_->requestStart();
        if (r != oboe::Result::OK) {
            LOGE("Не стартовал вход: %s", oboe::convertToText(r));
            closeStreamsLocked();
            return false;
        }
        r = outStream_->requestStart();
        if (r != oboe::Result::OK) {
            LOGE("Не стартовал выход: %s", oboe::convertToText(r));
            closeStreamsLocked();
            return false;
        }
        running_.store(true);
        return true;
    }

    void closeStreamsLocked() {
        running_.store(false);
        // Сначала выход (останавливает колбэк), потом вход.
        if (outStream_) {
            outStream_->requestStop();
            outStream_->close();
            outStream_.reset();
        }
        if (inStream_) {
            inStream_->requestStop();
            inStream_->close();
            inStream_.reset();
        }
        ai_.stopWorker();
    }

    std::mutex mtx_;
    std::shared_ptr<oboe::AudioStream> inStream_, outStream_;

    std::atomic<float> params_[PARAM_COUNT];
    std::atomic<bool>  running_{false};
    std::atomic<bool>  wantRunning_{false};
    std::atomic<bool>  restarting_{false};

    std::vector<float> scratch_, dry_;
    dsp::FloatRing     micRing_;
    dsp::ManualFx      fx_;
    AiEngine           ai_;
    bool               lastUseAi_ = false;
    bool               aiPrimed_ = false;
};

static std::shared_ptr<FishEngine> g_engine = std::make_shared<FishEngine>();

// ============================================================================
//  JNI  (класс fish.voice.MainActivity)
// ============================================================================
namespace {
// Менять модель/голос можно только при остановленных потоках: останавливаем и снова запускаем.
struct EngineStopper {
    bool wasRunning;
    EngineStopper() : wasRunning(g_engine->isRunning()) { if (wasRunning) g_engine->stop(); }
    ~EngineStopper() { if (wasRunning) g_engine->start(); }
};
}  // namespace

extern "C" {

JNIEXPORT void JNICALL
Java_fish_voice_MainActivity_startAudio(JNIEnv*, jobject) {
    g_engine->start();
}

JNIEXPORT void JNICALL
Java_fish_voice_MainActivity_stopAudio(JNIEnv*, jobject) {
    g_engine->stop();
}

JNIEXPORT void JNICALL
Java_fish_voice_MainActivity_setParam(JNIEnv*, jobject, jint paramId, jfloat value) {
    g_engine->setParam(static_cast<int>(paramId), static_cast<float>(value));
}

// Загрузка пяти ONNX-графов из каталога (скачанных приложением); highQuality — модели fp32 и 3 шага.
JNIEXPORT jboolean JNICALL
Java_fish_voice_MainActivity_initAi(JNIEnv* env, jobject, jstring modelDir, jboolean highQuality) {
    if (!modelDir) return JNI_FALSE;
    const char* chars = env->GetStringUTFChars(modelDir, nullptr);
    const std::string dir(chars ? chars : "");
    if (chars) env->ReleaseStringUTFChars(modelDir, chars);
    EngineStopper guard;
    return g_engine->ai().loadModels(dir, highQuality == JNI_TRUE) ? JNI_TRUE : JNI_FALSE;
}

// Целевой женский голос: эмбеддинг из 256 чисел.
JNIEXPORT jboolean JNICALL
Java_fish_voice_MainActivity_setTargetVoice(JNIEnv* env, jobject, jfloatArray embedding) {
    if (!embedding) return JNI_FALSE;
    const jsize n = env->GetArrayLength(embedding);
    std::vector<float> v(static_cast<size_t>(n));
    env->GetFloatArrayRegion(embedding, 0, n, v.data());
    EngineStopper guard;
    return g_engine->ai().setVoice(v.data(), v.size()) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_fish_voice_MainActivity_isAiReady(JNIEnv*, jobject) {
    return g_engine->ai().ready() ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_fish_voice_MainActivity_isAudioRunning(JNIEnv*, jobject) {
    return g_engine->isRunning() ? JNI_TRUE : JNI_FALSE;
}

// Среднее время обработки одного 160-мс куска, мс (для индикатора нагрузки).
JNIEXPORT jint JNICALL
Java_fish_voice_MainActivity_aiLoadMs(JNIEnv*, jobject) {
    return static_cast<jint>(g_engine->ai().loadMs() + 0.5f);
}

JNIEXPORT jstring JNICALL
Java_fish_voice_MainActivity_aiError(JNIEnv* env, jobject) {
    return env->NewStringUTF(g_engine->ai().lastError().c_str());
}

}  // extern "C"
